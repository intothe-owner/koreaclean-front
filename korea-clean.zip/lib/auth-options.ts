// lib/auth-options.ts
import type { NextAuthOptions } from "next-auth";
import Credentials from "next-auth/providers/credentials";

type LoginResponse = {
  is_success: boolean;
  message?: string;
  data?: {
    user: {
      id: number | string;
      email: string;
      name?: string | null;
      inst?: string | null;
      contact?: string | null;
      phone?: string | null;
      role?: "SUPER" | "ADMIN" | "CLIENT" | "COMPANY" | string;
      provider?: string;
      createdAt?: string;
      updatedAt?: string;
    };
    accessToken?: string;
    refreshToken?: string;
  };
};

export const authOptions: NextAuthOptions = {
  providers: [
    Credentials({
      id: "credentials",
      name: "Email & Password",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
        rememberMe: { label: "Remember", type: "checkbox" },
      },
      async authorize(credentials) {
        const base = process.env.NEXT_PUBLIC_API_BASE ?? "";
        const res = await fetch(`${base}/api/users/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include", // 쿠키도 유지 (백엔드 access_token 설정 시)
          body: JSON.stringify({
            email: credentials?.email,
            password: credentials?.password,
            rememberMe: credentials?.rememberMe === "on" || credentials?.rememberMe === "true",
          }),
        });

        const data = (await res.json()) as LoginResponse;

        if (!res.ok || !data?.is_success || !data?.data?.user) {
          throw new Error(data?.message || "로그인 실패");
        }

        // NextAuth의 "user" 객체로 반환: jwt 콜백에서 합쳐짐
        return {
          ...data.data.user,
          accessToken: data.data.accessToken,
          refreshToken: data.data.refreshToken,
        } as any;
      },
    }),
  ],
  session: {
    strategy: "jwt", // 쿠키 세션이지만 payload는 JWT로
    maxAge: 30 * 60,  // 30분 (백엔드 access_token 만료와 맞추면 관리 쉬움)
  },
  callbacks: {
    async jwt({ token, user }) {
      // 최초 로그인 시 user가 존재
      if (user) {
        token.user = {
          id: (user as any).id,
          email: (user as any).email,
          name: (user as any).name ?? null,
          inst: (user as any).inst ?? null,
          contact: (user as any).contact ?? null,
          phone: (user as any).phone ?? null,
          role: (user as any).role ?? null,
          provider: (user as any).provider ?? "local",
        };
        token.accessToken = (user as any).accessToken ?? null;
        token.refreshToken = (user as any).refreshToken ?? null;
      }
      return token;
    },
    async session({ session, token }) {
      // 클라이언트에서 session.user.* 사용 가능
      (session as any).user = token.user;
      (session as any).accessToken = token.accessToken ?? null;
      (session as any).refreshToken = token.refreshToken ?? null;
      return session;
    },
  },
  pages: {
    signIn: "/login", // 커스텀 로그인 페이지 사용
  },
};
