// app/page.tsx
'use client';
import { Button } from '@/components/ui/button';
import Footer from '@/components/app/Footer';
import Header from '@/components/app/Header';
import CenterSwiper from '@/components/app/CenterSwiper';
import CompanyRegisterForm from '@/components/app/ComponyRegisterForm';


export default function Request() {


  return (
    <div className="relative w-full min-h-screen bg-[#f9f5f2]">
      {/* 헤더 */}
      <Header />
    
     
      <section className="relative z-10 bg-[#f9f5f2]">
        <div className="max-w-7xl mx-auto px-6 pt-8 pb-12">
          <CompanyRegisterForm />
        </div>
      </section>


      <Footer />
    </div>
  );
}
