// app/page.tsx
'use client';



import Header from '@/components/app/Header';
import Footer from '@/components/app/Footer';





import ServiceRequestForm from '@/components/app/ServiceRequestForm';
import { useSession } from 'next-auth/react';

export default function Request() {
  const { data: session, status } = useSession();


  return (
    <div className="relative w-full min-h-screen bg-[#f9f5f2]">
      <Header />
      
      <section className="relative z-10 bg-[#f9f5f2]">
        <div className="max-w-7xl mx-auto px-6 pt-8 pb-12">
          <ServiceRequestForm/>
        </div>
      </section>

      <Footer />
    </div>
  );
}
