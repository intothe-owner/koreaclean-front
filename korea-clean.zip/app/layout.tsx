// app/layout.tsx
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { SessionProvider } from "next-auth/react";
import ReactQueryProvider from "./providers/ReactQueryProvider";
import SiteInfoProvider from "./providers/SiteInfoProvider";
import SwBoot from "./SwBoot";
import { fetchSiteInfoForMeta } from "@/lib/function";
import { baseUrl } from "@/lib/variable";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

// 안전 파서: 배열/JSON 문자열/콤마 구분 대응
function parseMetaTags(input: unknown): string[] {
  if (!input) return [];
  if (Array.isArray(input)) {
    return input.map(String).map(s => s.trim()).filter(Boolean).slice(0, 20);
  }
  if (typeof input === "string") {
    const v = input.trim();
    if (!v) return [];
    if (v.startsWith("[") && v.endsWith("]")) {
      try { const arr = JSON.parse(v); if (Array.isArray(arr)) return parseMetaTags(arr); } catch {}
    }
    return v.split(/[,\s]+/).map(s => s.trim()).filter(Boolean).slice(0, 20);
  }
  return [];
}

// ✅ 동적 메타 생성
// app/layout.tsx
export async function generateMetadata(): Promise<Metadata> {
  const site = await fetchSiteInfoForMeta();
  const defaultTitle = "경로당 케어 닷컴";
  const title = site?.site_name || defaultTitle;
  const description = site?.site_description || "경로당 맞춤형 청소";

  // 절대경로 보정
  const rawIcon = site?.icon_url
    ? (/^https?:\/\//i.test(site.icon_url) ? site.icon_url : `${baseUrl}${site.icon_url}`)
    : "/favicon.png"; // <- PNG 기본값으로

  // 캐시버전(업데이트 시점이 있다면 그걸 쓰고, 없으면 Date.now)
  const v = site?.updatedAt ? new Date(site.updatedAt).getTime() : Date.now();
  const iconUrl = `${rawIcon}${rawIcon.includes("?") ? "&" : "?"}v=${v}`;

  const keywords = parseMetaTags(site?.meta_tags);
  const metadataBase =
    process.env.NEXT_PUBLIC_BASE_URL
      ? new URL(process.env.NEXT_PUBLIC_BASE_URL)
      : process.env.VERCEL_URL
      ? new URL(`https://${process.env.VERCEL_URL}`)
      : undefined;

  return {
    metadataBase,
    title: { default: title, template: `%s | ${title}` },
    description,
    keywords,
    // 🔸 PNG 타입/사이즈 명시 + 다양한 rel에 동일 적용
    icons: {
      icon: [
        { url: iconUrl, type: "image/png", sizes: "any" },
      ],
      shortcut: [{ url: iconUrl, type: "image/png" }],
      apple: [{ url: iconUrl }], // iOS 홈화면 아이콘 겸용
    },
    openGraph: {
      type: "website",
      title,
      description,
      images: iconUrl ? [{ url: iconUrl }] : [],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: iconUrl ? [iconUrl] : [],
    },
    alternates: { canonical: "/" },
  };
}


export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        <SwBoot />
        <SessionProvider>
          <ReactQueryProvider>
            <SiteInfoProvider>{children}</SiteInfoProvider>
          </ReactQueryProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
