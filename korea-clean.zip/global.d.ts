interface Window {
    Kakao: any;
    kakao?:any;
    daum?: any;
}